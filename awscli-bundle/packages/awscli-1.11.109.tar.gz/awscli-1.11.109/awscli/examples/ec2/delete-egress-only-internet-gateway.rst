**To delete an egress-only Internet gateway**

This example deletes the specified egress-only Internet gateway.

Command::

  aws ec2 delete-egress-only-internet-gateway --egress-only-internet-gateway-id eigw-01eadbd45ecd7943f

Output::

  {
    "ReturnCode": true
  }